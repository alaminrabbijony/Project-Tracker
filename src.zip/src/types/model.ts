export type Task = {
  id: string;
  name: string;
  createdAt: Date;
  finishedAt: Date | null ;
};

export type Process = {
    id: string;
    taskId: string;
    name: string;
}

export type Log = {
    id: string;
    processId: string;
    msg?: string;
    img?: {uri: string, caption?: string};
    audio?: string;
    createdAt: Date;
    // more needed
}

// Nested Structures

export type TaskWithProgress = {
    processes: Process[];
}

export type ProcessWithLog = {
    logs: Log[]
}
